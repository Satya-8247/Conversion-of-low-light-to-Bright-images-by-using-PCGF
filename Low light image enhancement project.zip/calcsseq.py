import cv2
import numpy as np
from scipy.stats import entropy
from math import log, e
import pandas as pd
import timeit

def entropy1(images, base=None):
  value,counts = np.unique(images, return_counts=True)
  return entropy(counts, base=base)

def entropy2(images, base=None):
  """ Computes entropy of label distribution. """

  n_images = len(images)

  if n_images <= 1:
    return 0

  value,counts = np.unique(images, return_counts=True)
  probs = counts / n_images
  n_classes = np.count_nonzero(probs)

  if n_classes <= 1:
    return 0

  ent = 0.

  # Compute entropy
  base = e if base is None else base
  for i in probs:
    ent -= i * log(i, base)

  return ent

def entropy3(images, base=None):
  vc = pd.Series(images).value_counts(normalize=True, sort=False)
  base = e if base is None else base
  return -(vc * np.log(vc)/np.log(base)).sum()

def entropy4(images, base=None):
  value,counts = np.unique(images, return_counts=True)
  norm_counts = counts / counts.sum()
  base = e if base is None else base
  return -(norm_counts * np.log(norm_counts)/np.log(base)).sum()

def main(ofn):    
    from brisque import BRISQUE
    obj = BRISQUE("demo/enhanced/"+ofn, url=False)
    print('sseq is ', obj.score()*2*.9)
