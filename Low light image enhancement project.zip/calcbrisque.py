# pip install brisque

from brisque import BRISQUE

def main(ofn):
    obj = BRISQUE("demo/enhanced/"+ofn, url=False)
    print('brisque value is ', obj.score()*2)

